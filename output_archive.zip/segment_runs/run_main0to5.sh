#! /bin/bash
#SBATCH --chdir='/data/engs-df-green-ammonia/engs2523/lcoa-opt/LCOA_Optimisation'
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=32
#SBATCH --partition=short,medium
#SBATCH --time=12:00:00
#SBATCH --clusters=all
#SBATCH --mail-type=BEGIN,END
#SBATCH --mail-user=carlo.palazzi@eng.ox.ac.uk

# After SBATCH section of script

module purge
module load Anaconda3/2022.05
module load Gurobi/9.5.2-GCCcore-11.3.0
echo "Which Python: $(which python)"
source activate $DATA/lcoa-opt-env
echo "Which Python: $(which python)"

# Your Python commands here...
python main0to5.py

