import os

setwd = os.path.join(os.getcwd(), 'segment_runs')

# Define the range of intervals
start_range = -180
end_range = 180
step = 5

# Read the template file
with open(os.path.join(setwd,"main-180to-175.py"), "r") as template_file:
    template_content = template_file.read()

# Create copies of the file for each interval
for min_lon in range(start_range, end_range, step):
    max_lon = min_lon + step
    filename = f"main{min_lon}to{max_lon}.py"

    # Replace the values in the template content
    updated_content = template_content.replace("min_lon=-180", f"min_lon={min_lon}")
    updated_content = updated_content.replace("max_lon=-175", f"max_lon={max_lon}")

    # Write the updated content to the new file
    with open(os.path.join(setwd,filename), "w") as new_file:
        new_file.write(updated_content)

print("Files created successfully.")
