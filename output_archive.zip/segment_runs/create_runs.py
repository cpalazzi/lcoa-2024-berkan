import os

setwd = os.path.join(os.getcwd(), 'segment_runs')

# Define the range of intervals
start_range = -180
end_range = 180
step = 5

# Read the template file
with open(os.path.join(setwd,"run_main-180to-175.sh"), "r") as template_file:
    template_content = template_file.read()

# Create copies of the file for each interval
for min_lon in range(start_range, end_range, step):
    max_lon = min_lon + step
    filename = f"run_main{min_lon}to{max_lon}.sh"

    # Replace the values in the template content
    updated_content = template_content.replace("python main-180to-175.py", f"python main{min_lon}to{max_lon}.py")

    # Write the updated content to the new file
    with open(os.path.join(setwd,filename), "w") as new_file:
        new_file.write(updated_content)

print("Files created successfully.")
